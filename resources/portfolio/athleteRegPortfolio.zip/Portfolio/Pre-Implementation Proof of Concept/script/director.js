var fadeTime = 200;
var fadeType = 'linear';

/* Assign Event Listeners */
// Listen on the doc.
$(document).on('click', '.collapsible', function() {
	// Log the clicked element in the console
  if ($(this).hasClass('expand')) {
    $(this).html('remove');
    $(this).parent().next('div.content').show();
  }
  else {
    $(this).html('add');
    $(this).parent().next('div.content').hide();
  }
  $(this).toggleClass('expand');
  $(this).toggleClass('collapse');
});

/* Tree Interaction */
$('.item').on("click", $(this), function() {
  if($(this).next('.nested').hasClass('is-visible')) {
    $(this).next(".nested").hide();
    $(this).children("i").html('add_circle_outline');
  }
  else {
    $(this).next(".nested").show();
    $(this).children("i").html('remove_circle_outline');
  }
  $(this).next(".nested").toggleClass("is-visible");
  $(this).toggleClass("expanded");
  }
);

/* Dropdown  */
$('.dropdown').on("click", $(this), function() {
    if($(this).children('.options').is(":visible")) {
      $(this).children(".options").hide();
      $(this).find("i").removeClass("rotate-90");
    }
    else {
      $(this).children(".options").show();
      $(this).find("i").addClass("rotate-90");
    }
  }
);