/* Dropdown Logic */

function hideDropdown(menu, hide) {
  if (hide) {
    menu.removeClass("expanded");
    menu.parent(".dropdown").removeClass("expanded");
    menu.removeClass("grayborder"); // Add border.
  } else {
    menu.addClass("expanded");
    menu.parent(".dropdown").addClass("expanded");
    menu.addClass("grayborder"); // Add border.
  }
}

$("body").on("click", ".more", function() {
  var menu = $(this)
    .parent()
    .children(".options");

  if (menu.is(":visible")) {
    hideDropdown(menu, true);
  } else {
    // Close all before opening a new one.
    var menus = $(".options");
    hideDropdown(menus, true);

    hideDropdown(menu, false);
  }
});

$(document).click(function(event) {
  $target = $(event.target);
  if (!$target.closest(".more").length && $(".options").is(":visible")) {
    var menus = $(".options");

    hideDropdown(menus, true);
  }
});
