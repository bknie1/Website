# 2019 Asset Guide

## Summary
This asset guide was created to assure consistency across site pages.

**Director** has a more general demo of assets.

**Grid** a CSS Grid constructed table (the most difficult card concept) with fluid type (Desktop -> Mobile), fake, lengthy data, and re-orients itself on mobile.

## Inverted Triangle Stylesheet Organization

The philosophy of the inverted triangle serves both to improve style navigation and remind the engineer to be mindful about what should be edited and where it should go.

![Inverted Triangle Organization](https://github.com/bknie1/AssetGuide/blob/master/documentation/Inverted%20Triangle%20Organizaton.png)

Here, global styles should dominate the stylesheet. That is, styles that apply to every aspect of the website. These should occur more often than not.

Components are reasonably segregated and included on the pages where they are applicable. This way, we reduce overhead on pages where they are not applicable. For example we do not need to import tree styles on every page. In fact, there are only a few director side pages that make use of them. Components take up the second largest amount of space and, in some cases, are globally included (buttons, inputs).

Supporting files such as variables, mixins, and functions are more auxiliary in nature; the sheet is rarely referred to directly and, again, is only included where it is appropriate. For example, the director stylesheet makes no use of these Sass specific things, and only pure, basic CSS, and therefore does not need to include them. Alternatively, Grid makes extensive use of both variables and mixins for color, fluid font type, and shadowing.

The user experience doesn't vary that greatly, and therefore, while each user still maintains its own separate section for specific styles, it will likely remain fairly limited, as both draw heavily on global styles. Still, there will be a time and a place, and therefore this space is available. Right now, director is merely used to force a 998 content width. It may be used later to handle the director task sub menu effort as that feature only exists on the director side.

Finally, we have overrides, more commonly referred to as trump styles. This is a last resort and, if the developer is tempted to place something here, there is very likely a better design pattern that may be taken advantage of. Again, there is a time and a place, and so it must still exist, but the structure forces the engineer to re-evaluate the necessity and placement of their change.
